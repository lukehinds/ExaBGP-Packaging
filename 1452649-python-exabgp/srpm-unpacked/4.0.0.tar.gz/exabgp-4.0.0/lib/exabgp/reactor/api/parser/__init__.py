class Parser (object):
	from exabgp.reactor.api.parser.text import Text
